package com.example.flashcard;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.view.ViewParent;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        // make the x button return to main page
        findViewById(R.id.x_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        findViewById(R.id.save_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText edit_ques = findViewById(R.id.Edit_Question);
                EditText edit_ans = findViewById(R.id.Edit_Answer);
                if(edit_ans.getText().toString().equals("") || edit_ques.getText().toString().equals("")) {
                    Toast.makeText(MainActivity2.this, "Must enter both Question and Answer", Toast.LENGTH_SHORT).show();
                }else {
                    Intent data = new Intent();
                    String inputQuestion = ((EditText) findViewById(R.id.Edit_Question)).getText().toString();
                    String inputAnswer = ((EditText) findViewById(R.id.Edit_Answer)).getText().toString();
                    String edit_1 = ((EditText) findViewById(R.id.edit1)).getText().toString();
                    String edit_2 = ((EditText) findViewById(R.id.edit2)).getText().toString();
                    String edit_3 = ((EditText) findViewById(R.id.edit3)).getText().toString();
                    data.putExtra("Question_Key", inputQuestion);
                    data.putExtra("Answer_Key", inputAnswer);
                    data.putExtra("Box1_key",edit_1);
                    data.putExtra("Box2_key",edit_2);
                    data.putExtra("Box3_key",edit_3);
                    //end
                    setResult(RESULT_OK, data);
                    finish();
                }
            }

        });
        //This is the Textview > Edit View
        String s1 = getIntent().getStringExtra("KeyQ"); // this string will be card Front
        String s2 = getIntent().getStringExtra("KeyA");
        EditText edit1 = findViewById(R.id.Edit_Question);
        EditText edit2 = findViewById(R.id.Edit_Answer);
        EditText m1 = findViewById(R.id.edit1);
        EditText m2 = findViewById(R.id.edit2);
        EditText m3 = findViewById(R.id.edit3);
        edit1.setText(s1);
        edit2.setText(s2);
        String m_1 = getIntent().getStringExtra("M_1");
        String m_2 = getIntent().getStringExtra("M_2");
        String m_3 = getIntent().getStringExtra("M_3");
        m1.setText(m_1);
        m2.setText(m_2);
        m3.setText(m_3);
    }
}
