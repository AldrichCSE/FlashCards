package com.example.flashcard;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView flashcardQuestion = findViewById(R.id.flashcard_question);
        TextView flashcardAnswer = findViewById(R.id.Barack_Obama);
        TextView box_1 = findViewById(R.id.Box_1);
        TextView box_2 = findViewById(R.id.Box_2);
        TextView box_3 = findViewById(R.id.Box_3);
        flashcardQuestion.setOnClickListener(v -> {
            flashcardQuestion.setVisibility(View.INVISIBLE);
            flashcardAnswer.setVisibility(View.VISIBLE);

        });
        flashcardAnswer.setOnClickListener(v -> {
            //flip
            flashcardQuestion.setVisibility(View.VISIBLE);
            flashcardAnswer.setVisibility(View.INVISIBLE);
        });
        box_1.setOnClickListener(view -> {
            //color change on click:Red
            box_1.getBackground().mutate().setColorFilter(getColor(R.color.red), PorterDuff.Mode.MULTIPLY);
            box_3.getBackground().mutate().setColorFilter(getColor(R.color.green), PorterDuff.Mode.MULTIPLY);
        });
        box_2.setOnClickListener(view -> {
            //color change on click: Red
            box_2.getBackground().mutate().setColorFilter(getColor(R.color.red), PorterDuff.Mode.MULTIPLY);
            box_3.getBackground().mutate().setColorFilter(getColor(R.color.green), PorterDuff.Mode.MULTIPLY);
        });
        box_3.setOnClickListener(view -> box_3.getBackground().mutate().setColorFilter(getColor(R.color.green), PorterDuff.Mode.MULTIPLY));

        findViewById(androidx.constraintlayout.widget.R.id.parent).setOnClickListener(view -> {
            //Revert to original color scheme: clear multiply
            box_1.getBackground().mutate().clearColorFilter();
            box_2.getBackground().mutate().clearColorFilter();
            box_3.getBackground().mutate().clearColorFilter();
        });
        findViewById(R.id.add_card_activity).setOnClickListener(view -> {
            //open up a new page
            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
            startActivityForResult(intent, 100);
        });
        //on edit text click we should be able to grab Textview to EditView
        //Requestcode 100 is already used so we will use that, we need to implement a get string on Main1
        //refer to the save data button but just use it here under edit
        findViewById(R.id.edit_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //open up a new page
                Intent intent = new Intent(MainActivity.this,MainActivity2.class);
                //pass data as string
                String question = ((TextView) findViewById(R.id.flashcard_question)).getText().toString();
                String answer = ((TextView) findViewById(R.id.Barack_Obama)).getText().toString();
                String m1 = ((TextView) findViewById(R.id.Box_1)).getText().toString();
                String m2 = ((TextView) findViewById(R.id.Box_2)).getText().toString();
                String m3 = ((TextView) findViewById(R.id.Box_3)).getText().toString();
                //add Key to data
                intent.putExtra("KeyQ",question);
                intent.putExtra("KeyA",answer);
                intent.putExtra("M_1",m1);
                intent.putExtra("M_2",m2);
                intent.putExtra("M_3",m3);
                //end action
                startActivityForResult(intent,100);
            }
        });
        //onCreate data code
        flashcardDatabase = new FlashcardDatabase(getApplicationContext());
        allFlashcards = flashcardDatabase.getAllCards();
        //save to card
        if (allFlashcards != null && allFlashcards.size() > 0) {
            ((TextView) findViewById(R.id.flashcard_question)).setText(allFlashcards.get(0).getQuestion());
            ((TextView) findViewById(R.id.Barack_Obama)).setText(allFlashcards.get(0).getAnswer());
        }
        //OnClickListener for Next Button w/save (NEW CARD is NOT BEING ADDED)
        findViewById(R.id.next_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allFlashcards.size() == 0 )
                return;
                //counter 1+
                currentCardDisplayedIndex++;

                // make sure we don't get an IndexOutOfBoundsError if we are viewing the last indexed card in our list
                if(currentCardDisplayedIndex >= allFlashcards.size()) {
                    View parent = findViewById(R.id.parent);
                    Snackbar.make(parent,
                            "You've reached the end of the cards, going back to start.",
                            Snackbar.LENGTH_SHORT)
                            .show();
                    currentCardDisplayedIndex = 0;
                }

                // set the question and answer TextViews with data from the database
                allFlashcards = flashcardDatabase.getAllCards();
                Flashcard flashcard = allFlashcards.get(currentCardDisplayedIndex);

                ((TextView) findViewById(R.id.flashcard_question)).setText(flashcard.getAnswer());
                ((TextView) findViewById(R.id.Barack_Obama)).setText(flashcard.getQuestion());

            }
        });
        findViewById(R.id.trash_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flashcardDatabase.deleteCard(((TextView) findViewById(R.id.flashcard_question)).getText().toString());
                allFlashcards = flashcardDatabase.getAllCards();
                Flashcard flashcard = allFlashcards.get(currentCardDisplayedIndex);
                View parent = findViewById(R.id.parent);
                Snackbar.make(parent,"Deleted Card",Snackbar.LENGTH_SHORT).show();
            }
        });
    }

    //Outside onCreate in Main Activity
    //Data Variable
    FlashcardDatabase flashcardDatabase;
    // Flashcard List (THIS IS THE INDEX) starting from 1
    List<Flashcard> allFlashcards;
    //List Index
    int currentCardDisplayedIndex = 0;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) ;
            if (data != null) {
                //Get String_Keys
            String questionString = data.getExtras().getString("Question_Key");
            String answerstring = data.getExtras().getString("Answer_Key");
            String box1_s = data.getExtras().getString("Box1_key");
            String box2_s = data.getExtras().getString("Box2_key");
            String box3_s = data.getExtras().getString("Box3_key");
                //Create Values (next-time just initialize in main)
            TextView front = findViewById(R.id.flashcard_question);
            TextView back = findViewById(R.id.Barack_Obama);
            TextView box_1 = findViewById(R.id.Box_1);
            TextView box_2 = findViewById(R.id.Box_2);
            TextView box_3 = findViewById(R.id.Box_3);
                //Set Strings
            front.setText(questionString);
            back.setText(answerstring);
            box_1.setText(box1_s);
            box_2.setText(box2_s);
            box_3.setText(box3_s);
            //SNACKBAR IMPLEMENTATION
            View parent = findViewById(R.id.parent);
            Snackbar.make(parent,"Card successfully Created", Snackbar.LENGTH_SHORT).show();
            //Data Set (This line will store data) Location: Main,Onactivity Result
                flashcardDatabase.insertCard(new Flashcard(questionString, answerstring));
                allFlashcards = flashcardDatabase.getAllCards();
            }
    }
}