package com.example.flashcard;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.PorterDuff;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView flashcardQuestion = findViewById(R.id.flashcard_question);
        TextView flashcardAnswer = findViewById(R.id.Barack_Obama);
        TextView box_1 = findViewById(R.id.Box_1);
        TextView box_2 = findViewById(R.id.Box_2);
        TextView box_3 = findViewById(R.id.Box_3);
        flashcardQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flashcardQuestion.setVisibility(View.INVISIBLE);
                flashcardAnswer.setVisibility(View.VISIBLE);

            }
        });
        flashcardAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flashcardQuestion.setVisibility(View.VISIBLE);
                flashcardAnswer.setVisibility(View.INVISIBLE);
            }
        });
        box_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                box_1.getBackground().mutate().setColorFilter(getColor(R.color.red), PorterDuff.Mode.MULTIPLY);
                box_3.getBackground().mutate().setColorFilter(getColor(R.color.green), PorterDuff.Mode.MULTIPLY);
            }

            ;
        });
        box_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                box_2.getBackground().mutate().setColorFilter(getColor(R.color.red), PorterDuff.Mode.MULTIPLY);
                box_3.getBackground().mutate().setColorFilter(getColor(R.color.green), PorterDuff.Mode.MULTIPLY);
            }
        });
        box_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                box_3.getBackground().mutate().setColorFilter(getColor(R.color.green), PorterDuff.Mode.MULTIPLY);
            }
        });

        findViewById(androidx.constraintlayout.widget.R.id.parent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                box_1.getBackground().mutate().clearColorFilter();
                box_2.getBackground().mutate().clearColorFilter();
                box_3.getBackground().mutate().clearColorFilter();
            }
        });
    }
}